//package com.boat.services;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.json.simple.JSONObject;
//import org.json.simple.JSONValue;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Component; 
//
//@Component
//public class TopicConsumer {
//	
//	private final List<String> messages = new ArrayList<>();
//	
//	private final String url = "jdbc:postgresql://localhost/Boat";
//	private final String user = "postgres";
//	private final String password = "password";
//	
//	public Connection connect() {
//	    Connection conn = null;
//	    try {
//	        conn = DriverManager.getConnection(url, user, password);
//	        System.out.println("Connected to the PostgreSQL server successfully.");
//
//	    } catch (SQLException e) {
//	        System.out.println(e.getMessage());
//	    }
//
//	    return conn;
//	}
//
//
//    @KafkaListener(topics = "BoatData", groupId = "kafka-sandbox")
//    public void listen(String message) {
//    	
//    	Object file = JSONValue.parse(message); 
//    	
//    	JSONObject jsonObjectdecode = (JSONObject)file; 
//    	
//    	Long id =(Long)jsonObjectdecode.get("id"); 
//    	String engine_rpm=(String)jsonObjectdecode.get("engine_rpm"); 
//    	String engine_coolant_temp=(String)jsonObjectdecode.get("engine_coolant_temp");
//    	String run_time_since_engine_start =(String)jsonObjectdecode.get("run_time_since_engine_start");
//    	String engine_fuel_rate=(String)jsonObjectdecode.get("engine_fuel_rate");
//    	String odometer=(String)jsonObjectdecode.get("odometer");
//    	
// 
//    	//System.out.println(message);
//    	  
//    	TopicConsumer topicConsumer = new TopicConsumer();
//    	Connection conn = topicConsumer.connect();
//    	
//    	try {
//            Statement stmnt = null;
//            stmnt = connect().createStatement();
//            
//            String query = "INSERT INTO boatdata (hid, engine_rpm, engine_coolant_temp, run_time_since_engine_start, engine_fuel_rate, odometer ) VALUES(?,?,?,?,?,?)";
//            PreparedStatement pst = conn.prepareStatement(query);
////            String sql = "INSERT INTO boatdata (hid, engine_rpm, engine_coolant_temp, run_time_since_engine_start, engine_fuel_rate, odometer ) VALUES (id,engine_rpm,engine_coolant_temp,run_time_since_engine_start,engine_fuel_rate,odometer)";
////            		//+ "VALUES " +"(1,'rap','rab','value','data','dataa')";
////            		//+ "VALUES " + "( +  id + ", " +engine_rpm + ", " + engine_coolant_temp + ", " + run_time_since_engine_start  + ","+engine_fuel_rate+","+ odometer+  ")";
//          
//            pst.setLong(1,id);
//            pst.setString(2,engine_rpm);
//            pst.setString(3,engine_coolant_temp);
//            pst.setString(4,run_time_since_engine_start);
//            pst.setString(5,engine_fuel_rate);
//            pst.setString(6,odometer);
//            System.out.println("after insert");
////            stmnt.execute(query);
//            pst.executeUpdate();
//            System.out.println("Afterupdate");
//
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//    	
//        synchronized (messages) {
//            messages.add(message);
//        }
//    }
//
//    public List<String> getMessages() {
//        return messages;
//    }
//	
//
//}
